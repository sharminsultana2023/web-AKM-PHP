<?php include('partials-front/menu.php');?>

<!-- Categories Section Starts Here -->
<section class="categories">
    <div class="container">
        <h2 class="text-center">Explore Foods</h2>

        <?php
            // Display all the categories that are available
            // SQL Query

            $sql = "SELECT * FROM tbl_catagory WHERE active='Yes'";

            // Execute the Query
            $res = mysqli_query($conn, $sql);

            // count rows
            $count = mysqli_num_rows($res);

            // Check Whether categories are available or not
            if ($count > 0) {
                // categories available
                while ($row = mysqli_fetch_assoc($res)) {
                    // Get the values
                    $id = $row['id'];
                    $title = $row['title'];
                    $image_name = $row['image_name'];

                    ?>
                    <a href="category-foods.html">
                    <div class="box-3 float-container">
                    <?php

                     if ($image_name == "") {
                     // image not available
                     echo "<div class='error'>Image Not Found.</div>";
                     } 
                     else {
                                // Image Available
                        ?>
                        <img src="<?php echo SITEURL; ?>images/catagory/<?php echo $image_name; ?>"
                        alt="<?php echo $title; ?>" class="img-responsive img-curve">
                        <?php
                    }

                    ?>
                            <h3 class="float-text text-white"><?php echo $title; ?></h3>
                        </div>
                    </a>
                    <?php
                }
            } else {
                // categories not available
                echo "<div class='error'>Category not found.</div>";
            }
        ?>
        <a href="category-foods.html">
            <div class="box-3 float-container">
                <img src="images/pizza.jpg" alt="Pizza" class="img-responsive img-curve">
                <h3 class="float-text text-white">Pizza</h3>
            </div>
        </a>

        <div class="clearfix"></div>
    </div>
</section>
<!-- Categories Section Ends Here -->

<!-- Footer -->
<?php include('partials-front/footer.php');?>
