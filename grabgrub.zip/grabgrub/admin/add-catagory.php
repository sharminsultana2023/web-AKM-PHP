<?php include('partials/menu.php'); ?>

<div class="main-content">
    <div class="wrapper">
        <h1>Add Catagory</h1>

        <br><br>

        <?php

        if(isset($_SESSION['add']))
        {
            echo $_SESSION['add'];
            unset($_SESSION['add']);
        }
        // Show the message while uploading image
        if(isset($_SESSION['upload']))
        {
            echo $_SESSION['upload'];
            unset($_SESSION['upload']);
        }

        ?>

        <br><br>

        <!--Add Catagory Form Starts -->  <!--image upload: enctype="multipart/form-data" -->
        <form action="" method="POST" enctype="multipart/form-data">
            <table class="tbl_30">
                <tr>
                    <td>Title:</td>
                    <td>
                        <input type="text" name="title" placeholder="Catagory Title">
                    </td>
                </tr>

                <tr>
                    <td>Select Image: </td>
                    <td>
                        <input type="file" name="image">
                    </td>
                </tr>

                <tr>
                    <td>Featured:</td>
                    <td>
                      <input type="radio" name="featured" value="Yes">  Yes
                      <input type="radio" name="featured" value="No">  NO
                    </td>
                </tr>

                <tr>
                    <td>Active:</td>
                    <td>
                        <input type="radio" name="active" value="Yes"> Yes
                        <input type="radio" name="active" value="No"> NO
                    </td>
                </tr>

                <tr>
                    <td colspan="2">
                        <input type="submit" name="submit" value="Add Catagory" class="btn-secondary">
                    </td>
                </tr>
            </table>
        </form>

        <?php

            //Check whether the submit button is clicked or not
            if(isset($_POST['submit']))
            {
                //echo "clicked";

                //1. Get the values from catagory
                $title = $_POST['title'];

                // for radio input, we need to check whether the button selected or not.

                if(isset($_POST['featured']))
                {
                    //get the value from form
                    $featured = $_POST['featured'];
                }
                else
                {
                    //Set the default value.
                    $featured = "No";
                }
                if(isset($_POST['active']))
                {
                    $active = $_POST['active'];
                }
                else
                {
                    $active = "No";
                }

                //check whether the image is selected or not and set the value for image name accrodingly.
                if(isset($_FILES['image']['name']))
                {
                    //upload the image
                    //To upload image, we need source path and destination path
                    $image_name = $_FILES['image']['name'];

                    //Auto Rename Our Image
                    //Get the extension of our image (jpg, png, gif, etc) e.g. "food1.jpg"
                    
                    // Get the file extension using pathinfo
                    $filename = $_FILES['image']['name'];
                    $ext = pathinfo($filename, PATHINFO_EXTENSION);

                    // Rename the image
                    $image_name = "Food_Category_" . rand(000, 999) . '.' . $ext;



                    $source_path = $_FILES['image']['tmp_name'];
                    $destination_path = "../images/catagory/".$image_name;

                    //Upload image
                    $upload = move_uploaded_file($source_path, $destination_path);

                    //check whether the image is uploaded or not
                    //And if the image is not uploaded then we will stop the process and redirect with error message
                    if($upload==false)
                    {
                        //Set message
                        $_SESSION['upload'] = "<div class='error'>Failed to upload image.</div>";
                        //redirect to add catagory page
                        header('location: ' . SITEURL . 'admin/add-catagory.php');
                        //stop process
                        die();
                    }
                }
                else
                {
                    //don't upload image and set the image_name value as blank
                    $image_name="";
                }

                //2. SQL Query to insert category into the database
                $sql = "INSERT INTO tbl_catagory (title, image_name, featured, active) VALUES (
                    '$title',
                    '$image_name',
                    '$featured',
                    '$active'
                )";

                //3. Execute the Query and save in the database
                $res = mysqli_query($conn, $sql);


                //4. Check whether the query executed or not
                if($res==true)
                {
                    //Query executed and catagory added
                    $_SESSION['add'] = "<div class='success'>Catagory Added Successfully.</div>";
                    //redirect to manage catagory page
                    header("location:".SITEURL.'admin/manage-catagory.php');
                }
                else
                {
                    //failed to add catagory
                    $_SESSION['add'] = "<div class='error'>Catagory Added unsccessful.</div>";
                    //redirect to manage catagory page
                    header("location:".SITEURL.'admin/add-catagory.php');
                }
            }

        ?>


    </div>
</div>

<?php include('partials/footer.php'); ?>