<?php include('partials/menu.php'); ?>


<div class="main-content">
        <div class="wrapper">
            <h1>Update Password</h1>
            <br><br>

            <?php

                if(isset($_GET['id']))
                {
                    $id=$_GET['id'];
                }

            ?>


            <form action="" method="POST">

            <table class="tbl-30">
                <tr>
                    <td>Current Password: </td>
                    <td> <input type="password" name="current_password" placeholder="Your Current Password" value=""></td>
                </tr>

                <tr>
                    <td>New password: </td>
                    <td>
                        <input type="Password" name="new_password" placeholder="New Password" value="">
                    </td>
                </tr>

                <tr>
                    <td>Confirm password: </td>
                    <td>
                        <input type="Password" name="confirm_password" placeholder="Confirm Password" value="">
                    </td>
                </tr>

                
                <tr>
                    <td colspan="2">
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <input type="submit" name="submit" value="Change Password" class="btn-secondary">
                    </td>
                </tr>

            </table>

        </form>



        </div>
</div>

<?php

// Check whether the submit button is clicked or not.
if(isset($_POST['submit'])) {
    // 1. Get all the data from the form.
    $id = $_POST['id'];
    $current_password = md5($_POST['current_password']);
    $new_password = md5($_POST['new_password']);
    $confirm_password = md5($_POST['confirm_password']);

    // 2. SQL Query to check whether the user with the current ID and Current password exists or not
    $sql = "SELECT * FROM tbl_admin WHERE id=$id AND password='$current_password'";

    // Execute the Query
    $res = mysqli_query($conn, $sql);

    if ($res) {
        // Check if data is available or not.
        $count = mysqli_num_rows($res);

        if ($count == 1) {
            // Check whether the new password and confirm match or not.
            if($new_password == $confirm_password) {
                // Update password with SQL Query
                $sql2 = "UPDATE tbl_admin SET password='$new_password' WHERE id=$id";

                // Execute Query
                $res2 = mysqli_query($conn, $sql2);

                // Check whether the query executed or not
                if($res2) {
                    // Display success message and redirect
                    $_SESSION['change-pwd'] = "<div class='success2'>Password changed successfully.</div>";
                    header('location: ' . SITEURL . 'admin/manage-admin.php');
                } else {
                    // Display error message and redirect
                    $_SESSION['change-pwd'] = "<div class='error2'>Password change unsuccessful.</div>";
                    header('location: ' . SITEURL . 'admin/manage-admin.php');
                }
            } else {
                // Redirect to manage admin page with error message
                $_SESSION['pwd-not-match'] = "<div class='error2'>Password Did not match</div>";
                header('location: ' . SITEURL . 'admin/manage-admin.php');
            }
        }
    } else {
        // User does not exist, and password cannot be changed
        $_SESSION['user-not-found'] = "<div class='error2'>User not found. Try again</div>";
        header('location: ' . SITEURL . 'admin/manage-admin.php');
    }
}

?>





<?php include('partials/footer.php'); ?>