<?php
    //echo "Delete Food Page";
    //include constant page
    include('../config/constants.php');

    if(isset($_GET['id']) && isset($_GET['image_name']))
    {
        //process to delete
        //echo "Process to Delete";

        //1. Get ID and image name
        $id = $_GET['id'];
        $image_name = $_GET['image_name'];

        //2. Remove the image if available
        //Check Whether the image is available or not and delete only if available 
        if($image_name != "")
        {
            //it has an image, need to remove it from the folder
            //get the image path
            $path = "../images/Food/" . $image_name; // Fix: Added the missing directory separator ("/")

            //Remove Image file from the folder
            $remove = unlink($path);

            //check whether it is removed or not
            if($remove == false)
            {
                //failed to remove image
                $_SESSION['upload'] = "<div class='error'>Failed to remove image file</div>";

                //Redirect to manage food
                header('location: ' . SITEURL . 'admin/manage-food.php');

                //stop the process
                die();
            }
        }

        //3. Delete Food From the database
        //Create an SQL Query
        $sql = "DELETE FROM tbl_food WHERE id=$id";

        //execute the Query
        $res = mysqli_query($conn, $sql);

        //check whether the query executed or not and set the session message respectively
        //4. Redirect to manage food with a session message
        if($res == true)
        {
            //food deleted
            $_SESSION['delete'] = "<div class='success'>Food Deleted Successfully.</div>";
            //Redirect to manage food
            header('location: ' . SITEURL . 'admin/manage-food.php');
        }
        else
        {
            //food deletion error
            $_SESSION['delete'] = "<div class='error'>Failed to Delete Food.</div>";
            //Redirect to manage food
            header('location: ' . SITEURL . 'admin/manage-food.php');
        }
    }
    else
    {
        //redirect to manage food page
        //echo "Redirect";
        $_SESSION['unauthorize'] = "<div class='error'>Unauthorized Access.</div>";
        //redirect
        header('location: ' . SITEURL . 'admin/manage-food.php');
    }
?>
