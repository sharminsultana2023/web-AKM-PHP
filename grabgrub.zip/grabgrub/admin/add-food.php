<?php include('partials/menu.php'); ?> 

<div class="main-content">
    <div class="wrapper">
        <h1>Add Food</h1>
        <br> <br>

            <?php

                if(isset($_SESSION['upload']))
                {
                    echo $_SESSION['upload'];
                    unset( $_SESSION['upload']);
                }

            ?>

            <form action="" method="POST" enctype="multipart/form-data">

            <table class="tbl-30">

                <tr>
                    <td>Title:</td>
                    <td>
                        <input type="text" name="title" placeholder="Title of the food">
                    </td>
                </tr>

                <tr>
                    <td>Description:</td>
                    <td>
                        <textarea name="description" cols="30" rows="5" placeholder="Description of the food"></textarea>
                    </td>
                </tr>

                <tr>
                    <td>Price:</td>
                    <td>
                        <input type="number" name="price">
                    </td>
                </tr>

                <tr>
                    <td>Select Image: </td>
                    <td>
                        <input type="file" name="image">
                    </td>
                </tr>
                <tr>
                    <td>Catagory:</td>
                    <td>
                        <select name="catagory" id="">

                            <?php 
                                //crate php to display catagories from database
                                //1. create SQL to get all active catagories from database

                                $sql = "SELECT * FROM tbl_catagory WHERE active='Yes'";

                                //Executing Query
                                $res = mysqli_query($conn, $sql);

                                //Count rows to check whether we have catagories or not

                                $count = mysqli_num_rows($res);

                                //If count>0 then we have catagories otherwise empty.
                                if($count>0)
                                {
                                    //we have catagories
                                    while($row=mysqli_fetch_assoc($res))
                                    {
                                        //Get the details of catagories
                                        $id = $row['id'];
                                        $title = $row['title'];
                                        ?>

                                        <option value="<?php echo $id; ?>"><?php echo $title; ?></option>

                                        <?php
                                    }
                                }
                                else
                                {
                                    //we do not have catagory
                                    ?>

                                    <option value="0">No Catagory Found</option>

                                    <?php
                                }
                                //2.display on dropdown
                            
                            ?>



                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Featured:</td>
                    <td>
                        <input type="radio" name="featured" value="Yes">Yes
                        <input type="radio" name="featured" value="No">No
                    </td>
                </tr>

                <tr>
                    <td>Active</td>
                    <td>
                        <input type="radio" name="active" value="Yes">Yes
                        <input type="radio" name="active" value="No">No
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <input type="submit" name="submit" value="Add Food" class="btn-secondary">
                    </td>
                </tr>

            </table>
            
            </form>
            
            <?php

                //check whether the button is clicked or not
                if(isset($_POST['submit']))
                {
                    //add the food in database
                    //echo "Clicked"; 

                    //1. Get the data from form
                    $title = $_POST['title'];
                    $description = $_POST['description'];
                    $price = $_POST['price'];
                    $catagory = $_POST['catagory'];

                    //for feature and active whether the radio button are checked or not
                    if(isset($_POST['featured']))
                    {
                        $featured = $_POST['featured'];
                    }
                    else
                    {
                        $featured = "No"; //setting the default value
                    }
                    if(isset($_POST['active']))
                    {
                        $active = $_POST['active'];
    
                    }
                    else
                    {
                        $active = "No"; //setting the default value
                    }


                    //2. upload the image if selected
                    //check whether the select image is clicked or not and upload image only if the image is selected.
                    if(isset($_FILES['image']['name']))
                    {
                        //Get the details of the selected image
                        $image_name  =$_FILES['image']['name'];

                        //check whether the image is selected or not and upload image only if selected
                        if($image_name !="")
                        {
                            //image is selected
                            //A. rename the image
                            //get the extention of selected image (jpg,png...etc.)
                            $filename = $_FILES['image']['name'];
                            $ext = pathinfo($filename, PATHINFO_EXTENSION);
                            //create new image name like foodname123.jpg
                            $image_name = "Food_Name_" . rand(000, 999) . '.' . $ext;
                            //B. upload the image 
                            //get the source path of current location
                            $source_path = $_FILES['image']['tmp_name'];
                            //drive the data into destination
                            $destination_path = "../images/Food/" . $image_name;
                            //upload the image
                            $upload = move_uploaded_file($source_path, $destination_path);

                            //whether image uploaded or not
                            if($upload == false)
                            {
                                //failed to upload the image
                                //redirect to add food page with error message
                                $_SESSION['upload'] = "<div class='error'>Failed to upload image.</div>";
                                header('location: ' . SITEURL . 'admin/add-food.php');
                                //stop the process
                                die();
                            }
                            
                        }
                    }
                    else
                    {
                        $image_name = ""; //setting default value as blank
                    }

                    //3. Insert into database

                    //create a SQL Query to save or add food
                    //For numerical value we do not use quotes

                    $sql2 = "INSERT INTO tbl_food SET
                            title='$title',
                            description='$description',
                            price=$price, 
                            image_name='$image_name',
                            catagory_id=$catagory,
                            featured='$featured',
                            active='$active'
                    ";


                     //execute the Query
                     $res2 = mysqli_query($conn, $sql2);
                     // check whether data inserted or not

                     if($res2==true)
                     {
                        //data inserted successfully
                        $_SESSION['add'] = "<div class='success'>Food Added Successfully.</div>";
                        header('location: ' . SITEURL . 'admin/manage-food.php');

                     }
                     else
                     {
                        //failed to insert data
                        $_SESSION['add'] = "<div class='error'>Failed to add.</div>";
                        header('location: ' . SITEURL . 'admin/manage-food.php');
                     }

                    //4. Redirect with message to manage food page
                }

            ?>

    </div>
</div>

<?php include('partials/footer.php'); ?> 