<?php

    //include constants.php file here
    include('../config/constants.php');
    //1.Get the id of admin to be deleted
    $id = $_GET['id'];

    //2.Create SQL Query to delete admin
    $sql = "DELETE FROM tbl_admin WHERE id=$id";

    //Execute the query
    $res = mysqli_query($conn, $sql);

    //check whether the query executed successfully or not

    if ($res == true) {
        // Query Successfully executed and Admin Deleted.
        $_SESSION['delete'] = "<div class='success'>Admin Deleted Successfully</div>";
        // Redirect to manage admin page
        header('location: ' . SITEURL . 'admin/manage-admin.php');
    } else {
        // Failed to Delete admin
        $_SESSION['delete'] = "<div class='error'>Admin Deletion unsuccessful, Try again</div>";
        header('location: ' . SITEURL . 'admin/manage-admin.php');
    }
    

    //3. Redirect to manage admin page with message (success)
    
?>