<html>
    <head>
        <title>GrabGrub</title>
        <link rel="stylesheet" href="../css/admin.css">
    </head>
    <body>
                
    <div class="footer">
            <div class="wrapper">
                <p class="text-center">All rights reserved by Team-Accupia
                    <br> Developed by CSE- <a href="https://seu.edu.bd/">SEU</a>
                </p>
            </div>
        </div>

    </body>
    </head>
</html>