<?php
    //include constants files
    include('../config/constants.php');

    //echo "Delete Page";
    //Check Whether the id and image name value is set or not

    if(isset($_GET['id']) AND isset($_GET['image_name']))
    {
        //Get the value and delete
       // echo "Get value and Delete";
       $id = $_GET['id'];
       $image_name = $_GET['image_name'];

       //Remove the physical image file is available

       if($image_name != "")
       {
         //image available and we have to remove it
         $path = "../images/catagory/".$image_name;
         //remove the image
         $remove = unlink($path); //contains boolean value true false 0,1

         //if failed to remove image then add an error message and stop the process
         if($remove==false)
         {
            //set the session message
            $_SESSION['remove'] = "<div class='error'>Failed to remove Catagory image.</div>";
            //redirect to manage catagory page
            header('location: ' . SITEURL . 'admin/manage-catagory.php');
            //stop the process;
            die();
         }
       }

       //Delete Data from database
       $sql = "DELETE FROM tbl_catagory WHERE id=$id";

       //execute the Query
       $res = mysqli_query($conn, $sql);

       //Check whether the data is delete from database or not
       if($res==true)
       {
         //set the success message and redirect
         $_SESSION['delete'] = "<div class='success'>Catagory Deleted Successfully.</div>";
         //redirect to manage catagory
         header('location: ' . SITEURL . 'admin/manage-catagory.php');

       }
       else
       {
         //set failed message and redirect
         $_SESSION['delete'] = "<div class='error'>Catagory Deleted unsuccessful.</div>";
         //redirect to manage catagory
         header('location: ' . SITEURL . 'admin/manage-catagory.php');
       }

       

       
    }
    else
    {
        //redirect to manage catagory page
        header('location: ' . SITEURL . 'admin/manage-catagory.php');
    }

?>