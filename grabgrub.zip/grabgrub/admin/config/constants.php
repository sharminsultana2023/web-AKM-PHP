<?php

    //Start session

    session_start();

    //create constant to store Non Repeating Values
    define('SITEURL', 'http://localhost/grabgrub/');
    define('LOCALHOST', 'localhost');
    define('DB_USERNAME', 'root');
    define('DB_PASSWORD', ' ');
    define('DB_NAME', 'grabgrub');


$conn = mysqli_connect(LOCALHOST, DB_USERNAME, DB_PASSWORD) or die(mysqli_error()); //database connection
$db_select = mysqli_select_db($conn,'grabgrub') or die(mysqli_error());// selecting database

?>