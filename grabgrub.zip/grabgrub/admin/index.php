<?php include('partials/menu.php'); ?>


        <!--Main Content Section-->
        <div class="main-content">
                 <div class="wrapper">
                     <h1>Dashboard</h1>

                     <br> <br>
                  
                     <?php
                        //Login Message from Login.php
                        if(isset($_SESSION['login']))
                        {
                           echo $_SESSION['login'];
                           unset($_SESSION['login']);
                        }

                     ?>
                     
                     <br> <br>

                     <div class="col-4 text-center">
                        <h1>5</h1>
                        <br>
                        catagories
                     </div>

                     <div class="col-4 text-center">
                        <h1>5</h1>
                        <br>
                        catagories
                     </div>

                     <div class="col-4 text-center">
                        <h1>5</h1>
                        <br>
                        catagories
                     </div>

                     <div class="col-4 text-center">
                        <h1>5</h1>
                        <br>
                        catagories
                     </div>

                     <div class="clearfix"></div>

                     
                </div>
        </div>
        

        <?php include('partials/footer.php'); ?>

   </body>

</html>